# math-tools-nyu
DS-GA 1013 Mathematical Tools for Data Science
